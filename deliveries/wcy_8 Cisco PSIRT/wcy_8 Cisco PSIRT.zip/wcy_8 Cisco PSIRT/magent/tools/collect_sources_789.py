"""Collect public CERT/CC, Cisco and Fortinet sources; no default network I/O."""
from __future__ import annotations
import argparse
import asyncio
from collections import Counter
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]

from apps.vulntell.sources.public_789 import (PublicHTTP, CERTCCPublicAdapter, CiscoPublicAdapter,
                                            FortinetPublicAdapter, PARSER_VERSION)
from apps.vulntell.sources.protocol import SourceRequest
from apps.vulntell.batch.collector import collect_adapter


async def main(args):
    start = datetime.strptime(args.start, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end = datetime.strptime(args.end, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    if start >= end:
        raise ValueError("Start must precede end")
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    http = PublicHTTP(args.cache, offline=not args.live, workers=args.workers)
    result = {"window_start": start.isoformat(), "window_end_exclusive": end.isoformat(),
              "window_basis": "source_first_publication", "parser_version": PARSER_VERSION,
              "sources": {}, "collected_at": datetime.now(timezone.utc).isoformat()}
    summary_file = out / "collection-summary.json"
    if summary_file.exists():
        prior = json.loads(summary_file.read_text(encoding="utf-8"))
        if prior["window_start"] != result["window_start"] or prior["window_end_exclusive"] != result["window_end_exclusive"]:
            raise ValueError("Output already belongs to another time window")
        result["sources"].update(prior["sources"])
    adapters = {"certcc": CERTCCPublicAdapter, "cisco": CiscoPublicAdapter, "fortinet": FortinetPublicAdapter}
    failed = False
    for source in args.sources:
        print(f"Collecting {source} ...", flush=True)
        adapter = adapters[source](http)
        request = SourceRequest(source, "official-public-789", f"{args.start}_{args.end}", start, end)
        dest = out / source
        dest.mkdir(exist_ok=True)
        try:
            manifest, docs = await collect_adapter(adapter, request, dest, collector_id="241820271_wucaiying",
                                                   license="source publisher terms; research use; redistribution not independently cleared")
            manifest.cosv_parser_version = PARSER_VERSION
            pairs = adapter._records
            counts = Counter(r.payload.get("cve_id") for r in pairs if r.payload.get("cve_id"))
            quality = json.loads((dest / "quality.json").read_text(encoding="utf-8"))
            info = {"status": "ok" if not adapter.warnings else "partial_enrichment", **adapter.coverage,
                    "source_observations": len(pairs), "cosv_records": len(docs), "unique_cves": len(counts),
                    "cves_in_multiple_advisories": {c: n for c, n in counts.items() if n > 1},
                    "missing_cve_observations": sum(not r.payload.get("cve_id") for r in pairs),
                    "quality_issue_count": len(quality["issues"]), "warnings": adapter.warnings,
                    "duplicate_cosv_ids_policy": "Keep distinct advisory/CVE source observations; do not overwrite by CVE alone",
                    "parser_version": PARSER_VERSION}
            info["field_coverage"] = {key: sum(bool(r.payload.get(key)) for r in pairs) for key in
                                      ("title", "description", "published_at", "modified_at", "affected", "cvss_score", "cwe")}
            info["cvss_observations"] = sum(bool(r.payload.get("cvss_score") is not None or r.payload.get("severity")) for r in pairs)
            if len(docs) != len(pairs):
                info["status"] = "partial_schema"
                manifest.collection_complete = False
            if adapter.warnings:
                manifest.collection_complete = False
            from apps.vulntell.batch.manifest import save_manifest
            save_manifest(manifest, dest)
            (dest / "coverage.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
            with (dest / "source-observations.jsonl").open("w", encoding="utf-8") as f:
                for r in pairs:
                    f.write(json.dumps(r.to_dict(), ensure_ascii=False) + "\n")
            with (dest / "advisories.raw.jsonl").open("w", encoding="utf-8") as f:
                for a in adapter.advisories:
                    f.write(json.dumps(a, ensure_ascii=False) + "\n")
            with (dest / "overview.csv").open("w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["source_record_id", "CVE", "published_at_UTC", "modified_at_UTC", "title", "official_url"])
                for r in pairs:
                    p = r.payload
                    writer.writerow([r.source_record_id, p.get("cve_id"), p.get("published_at"), p.get("modified_at"), p.get("title"), p["references"][0]["url"]])
            result["sources"][source] = info
            print(f"  {source}: {len(adapter.advisories)} advisories, {len(pairs)} observations, {len(docs)} COSV; {info['status']}", flush=True)
            failed = failed or info["status"] != "ok"
        except Exception as exc:
            failed = True
            result["sources"][source] = {"status": "failed", "error": str(exc), "collection_complete": False}
            print(f"  FAILED {source}: {exc}", flush=True)
        summary_file.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        (out / "network-warnings.json").write_text(json.dumps(http.network_warnings, ensure_ascii=False, indent=2), encoding="utf-8")
        # Metadata only: never store cookies, response headers or tokens in audit.
        (out / "http-audit.json").write_text(json.dumps(http.audit, ensure_ascii=False, indent=2), encoding="utf-8")
    return 1 if failed else 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", help="Explicitly enable live official HTTP collection; default is cache-only replay")
    parser.add_argument("--sources", nargs="+", choices=["certcc", "cisco", "fortinet"], default=["certcc", "cisco", "fortinet"])
    parser.add_argument("--start", default="2024-09-10")
    parser.add_argument("--end", default="2026-09-15", help="Exclusive end date, UTC")
    parser.add_argument("--output", default=str(ROOT.parent / "delivery"))
    parser.add_argument("--cache", default=str(ROOT.parent / "live-cache"))
    parser.add_argument("--workers", type=int, default=3)
    sys.exit(asyncio.run(main(parser.parse_args())))
