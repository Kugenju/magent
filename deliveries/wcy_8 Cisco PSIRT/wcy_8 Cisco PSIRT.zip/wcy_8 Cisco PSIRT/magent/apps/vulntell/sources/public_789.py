"""Opt-in live collectors for CERT/CC, Cisco PSIRT and Fortinet PSIRT.

Only documented public APIs and the endpoints used by official public pages.
No login, CAPTCHA solving, cookie export or authentication bypass. A frozen
on-disk response cache supports replay; use a new cache directory to refresh.
Window semantics: source FIRST PUBLICATION in [start, end), not CVE year or
last modification. Advisory/CVE pairs are distinct source observations.
"""
from __future__ import annotations

import asyncio
import concurrent.futures
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import threading
import time
from urllib.parse import parse_qs, urlencode, urljoin, urlparse
import xml.etree.ElementTree as ET

from apps.vulntell.sources.protocol import SourcePage, SourceRecord

UTC = timezone.utc
PARSER_VERSION = "public-789/1.0"


def timestamp(value):
    if not value:
        return None
    try:
        d = datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))
    except ValueError:
        d = datetime.strptime(str(value), "%b %d, %Y")
    return d.replace(tzinfo=UTC) if d.tzinfo is None else d.astimezone(UTC)


def iso(value):
    d = timestamp(value)
    return d.isoformat().replace("+00:00", "Z") if d else None


def cves(value):
    return sorted({v.upper() for v in re.findall(r"\bCVE-\d{4}-\d{4,}\b", str(value or ""), re.I)})


def text(html):
    from bs4 import BeautifulSoup
    return BeautifulSoup(str(html or ""), "html.parser").get_text(" ", strip=True)


class PublicHTTP:
    """Bounded requests, HTTPS proxy verification, immutable cache and audit."""
    def __init__(self, cache_dir, *, workers=3, offline=False):
        import requests
        self.requests = requests
        self.root = Path(cache_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self.workers = max(1, min(4, workers))
        self.offline = offline
        self.local = threading.local()
        self.lock = threading.Lock()
        self.audit = []
        self.network_warnings = []
        self._fallback_checked = False
        self._fallback_available = False
        self.proxy = None
        if not offline:
            errors = []
            for proxy in ("http://127.0.0.1:7897", "http://127.0.0.1:7892"):
                try:
                    response = requests.get("https://github.com/Kugenju/magent", timeout=15,
                                            proxies={"http": proxy, "https": proxy})
                    response.raise_for_status()
                    self.proxy = proxy
                    break
                except requests.RequestException as exc:
                    errors.append(type(exc).__name__)
            if not self.proxy:
                raise RuntimeError("Both HTTPS proxy checks failed: " + ", ".join(errors))
            # Explicitly scope these environment variables to this process.
            import os
            for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY"):
                os.environ[key] = self.proxy

    def get(self, url, params=None):
        if params:
            # Cisco's public listing currently returns an empty HTTP 200 for
            # percent-encoded comma in publicationTypeIDs. Its own UI uses a
            # literal comma, so preserve that separator.
            url += ("&" if "?" in url else "?") + urlencode(sorted(params.items()), safe=",")
        if urlparse(url).scheme != "https":
            raise ValueError("Only HTTPS official resources are accepted")
        allowed = {"kb.cert.org", "www.kb.cert.org", "sec.cloudapps.cisco.com",
                   "www.fortiguard.com", "fortiguard.fortinet.com", "filestore.fortinet.com"}
        if urlparse(url).hostname not in allowed:
            raise ValueError("Non-official URL rejected: " + url)
        key = hashlib.sha256(url.encode()).hexdigest()
        body_path = self.root / (key + ".body")
        meta_path = self.root / (key + ".json")
        if body_path.exists() and meta_path.exists():
            body = body_path.read_bytes()
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if hashlib.sha256(body).hexdigest() != meta["sha256"]:
                raise ValueError("Cache hash mismatch: " + url)
        else:
            if self.offline:
                raise RuntimeError("Missing offline cache: " + url)
            if not hasattr(self.local, "session"):
                self.local.session = self.requests.Session()
                self.local.session.headers["User-Agent"] = "VulnTell-public-collector/1.0 (academic source assessment)"
                self.local.session.proxies.update({"http": self.proxy, "https": self.proxy})
            for attempt in range(3):
                time.sleep(0.15)
                try:
                    r = self.local.session.get(url, timeout=35, allow_redirects=True)
                    if urlparse(r.url).hostname not in allowed:
                        raise ValueError("Unexpected redirected host")
                    if r.status_code in (429, 500, 502, 503, 504) and attempt < 2:
                        time.sleep(min(30, max(1, int(r.headers.get("Retry-After", "2")))))
                        continue
                    r.raise_for_status()
                    body = r.content
                    meta = {"requested_url": url, "final_url": r.url, "status": r.status_code,
                            "content_type": r.headers.get("Content-Type"), "bytes": len(body),
                            "sha256": hashlib.sha256(body).hexdigest(),
                            "fetched_at": datetime.now(UTC).isoformat(),
                            "redirects": [{"status": h.status_code, "url": h.url} for h in r.history]}
                    body_path.write_bytes(body)
                    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
                    break
                except (self.requests.Timeout, self.requests.ConnectionError):
                    # Per-run fallback verification after a real request fails.
                    # Do not touch either VPN application or change its config.
                    if self.proxy == "http://127.0.0.1:7897":
                        with self.lock:
                            if not self._fallback_checked:
                                self._fallback_checked = True
                                try:
                                    check = self.requests.get("https://github.com/Kugenju/magent", timeout=15,
                                        proxies={"http": "http://127.0.0.1:7892", "https": "http://127.0.0.1:7892"})
                                    check.raise_for_status()
                                    self._fallback_available = True
                                except self.requests.RequestException:
                                    self.network_warnings.append({"kind": "proxy_fallback_unavailable",
                                        "failed_request": url, "fallback_proxy": "http://127.0.0.1:7892"})
                        if self._fallback_available:
                            self.proxy = "http://127.0.0.1:7892"
                            self.local.session.proxies.update({"http": self.proxy, "https": self.proxy})
                            import os
                            for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY"):
                                os.environ[key] = self.proxy
                    if attempt == 2:
                        raise
                    time.sleep(2 ** attempt)
        with self.lock:
            self.audit.append(meta)
        return body, meta

    def json(self, url, params=None):
        body, _ = self.get(url, params)
        result = json.loads(body)
        if isinstance(result, dict) and result.get("error"):
            raise ValueError("Official API returned a logical error: " + str(result["error"]))
        return result

    def map(self, fn, items):
        items = list(items)
        result = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.workers) as pool:
            for i, value in enumerate(pool.map(fn, items), 1):
                result.append(value)
                if i % 50 == 0 or i == len(items):
                    print(f"  details {i}/{len(items)}", flush=True)
        return result


def base_payload(identifier, title, description, published, modified, url, *, aliases=None):
    return {"title": title, "description": description, "published_at": iso(published),
            "modified_at": iso(modified), "source_added_at": iso(published),
            "aliases": aliases or [], "references": [{"type": "ADVISORY", "url": url}],
            "advisory_id": identifier}


def split_records(identifier, payload, identifiers, metadata, per_cve=None):
    """Never treat different CVEs in the same advisory as equivalent aliases."""
    records = []
    for cve in identifiers or [None]:
        p = dict(payload)
        p["aliases"] = list(payload.get("aliases", []))
        if cve:
            p["cve_id"] = cve
        if per_cve and cve in per_cve:
            p.update(per_cve[cve])
        records.append(SourceRecord(identifier + ("/" + cve if cve else ""), p,
                                    dict(metadata, advisory_id=identifier)))
    return records


class SnapshotAdapter:
    source = ""
    def __init__(self, http):
        self.http = http
        self._records = None
        self._fingerprint = None
        self.advisories = []
        self.coverage = {}
        self.warnings = []

    def in_window(self, value, request):
        d = timestamp(value)
        if d is None:
            raise ValueError("Missing first publication time; cannot filter safely")
        return request.window_start <= d < request.window_end

    async def fetch_page(self, request, cursor=None):
        if request.source != self.source:
            raise ValueError("Source/request mismatch")
        if self._records is None:
            self._records = await asyncio.to_thread(self.load, request)
            self._records.sort(key=lambda r: r.source_record_id)
            keys = [r.source_record_id for r in self._records]
            if len(keys) != len(set(keys)):
                raise ValueError("Duplicate source observation IDs")
            self._fingerprint = request.request_fingerprint
        if self._fingerprint != request.request_fingerprint:
            raise ValueError("Adapter snapshot cannot be reused for another request")
        offset = int(cursor or "0")
        if offset < 0 or offset > len(self._records):
            raise ValueError("Invalid snapshot cursor")
        end = min(offset + request.page_size, len(self._records))
        more = end < len(self._records)
        return SourcePage(records=tuple(self._records[offset:end]), next_cursor=str(end) if more else None,
                          has_more=more, page_index=offset // request.page_size, source=self.source,
                          observed_at=datetime.now(UTC), request_fingerprint=request.request_fingerprint)


class CERTCCPublicAdapter(SnapshotAdapter):
    source = "certcc"
    def load(self, request):
        base = "https://kb.cert.org/vuls/api/"
        ids = set()
        counts = {}
        for year in range(request.window_start.year, request.window_end.year + 1):
            summary = self.http.json(f"{base}{year}/summary/")
            notes = summary["notes"]
            if len(notes) != summary["count"]:
                raise ValueError("CERT yearly count mismatch")
            counts[str(year)] = len(notes)
            ids.update(n.removeprefix("VU#") for n in notes)

        def fetch(identifier):
            note = self.http.json(f"{base}{identifier}/")
            if not isinstance(note, dict) or note.get("idnumber") != identifier:
                raise ValueError("Unexpected CERT note format")
            if not self.in_window(note.get("datefirstpublished"), request):
                return None
            vendors = self.http.json(f"{base}{identifier}/vendors/")
            statuses = self.http.json(f"{base}{identifier}/vendors/vuls/")
            return note, vendors, statuses

        records = []
        for result in self.http.map(fetch, sorted(ids)):
            if not result:
                continue
            note, vendors, statuses = result
            identifier = note["vuid"]
            p = base_payload(identifier, note["name"], note.get("overview") or "",
                             note["datefirstpublished"], note.get("dateupdated"),
                             f"https://kb.cert.org/vuls/id/{note['idnumber']}/")
            p["references"] += [{"type": "WEB", "url": u} for u in note.get("public") or [] if u.startswith("https://")]
            # CERT vendor status is not an affected PRODUCT/version list.
            # Keep it in source metadata instead of inventing package names.
            p["affected"] = []
            if note.get("cvss_basescore") is not None:
                p.update(cvss_score=float(note["cvss_basescore"]), cvss_vector=note.get("cvss_basevector"), cvss_version="2.0")
            # firstpublic/updated rounding can differ by milliseconds; preserve it.
            metadata = {"source": self.source, "parser_version": PARSER_VERSION,
                        "publicdate": note.get("publicdate"), "vendors": vendors,
                        "vendor_vulnerability_statuses": statuses, "affected_scope": "advisory_vendor_level"}
            records += split_records(identifier, p, cves(note.get("cveids")), metadata)
            self.advisories.append({"advisory_id": identifier, "note": note, "vendors": vendors, "statuses": statuses})
        self.coverage = {"year_summary_counts": counts, "enumerated_notes": len(ids),
                         "window_advisories": len(self.advisories), "enumeration_complete": True}
        return records


def local_name(element):
    return element.tag.rsplit("}", 1)[-1]


def descendants(element, tag):
    return [e for e in element.iter() if local_name(e) == tag]


def first_text(element, tag):
    nodes = descendants(element, tag)
    return "".join(nodes[0].itertext()).strip() if nodes else None


def parse_cisco_cvrf(body):
    root = ET.fromstring(body)
    if local_name(root) != "cvrfdoc":
        raise ValueError("Expected CVRF XML, received HTML/challenge or other format")
    products = {e.attrib.get("ProductID"): "".join(e.itertext()).strip() for e in descendants(root, "FullProductName")}
    notes = descendants(root, "Note")
    summary = ["".join(n.itertext()).strip() for n in notes if n.attrib.get("Title") == "Summary"]
    sections = {n.attrib.get("Title", ""): "".join(n.itertext()).strip() for n in notes}
    per_cve = {}
    for vuln in descendants(root, "Vulnerability"):
        cve = first_text(vuln, "CVE")
        if not cve:
            continue
        entry = {"cwe": sorted(set(re.findall(r"CWE-\d+", first_text(vuln, "CWE") or "")))}
        if not entry["cwe"]:
            entry.pop("cwe")  # Preserve the listing CWE when CVRF omits it.
        affected = []
        for status in descendants(vuln, "Status"):
            if status.attrib.get("Type") == "Known Affected":
                affected += [{"name": products.get(p.text, p.text), "ecosystem": "Cisco"}
                             for p in descendants(status, "ProductID") if p.text in products]
        entry["affected"] = affected
        scores = descendants(vuln, "ScoreSetV3") or descendants(vuln, "ScoreSet")
        if scores:
            # Product-specific CVSS values are retained as separate measurements.
            entry["severity"] = []
            for score in scores:
                base = first_text(score, "BaseScoreV3") or first_text(score, "BaseScore")
                vector = first_text(score, "VectorV3") or first_text(score, "Vector")
                if base or vector:
                    stype = "CVSS_V31" if "3.1" in (vector or "") else "CVSS_V3" if local_name(score) == "ScoreSetV3" else "CVSS_V2"
                    entry["severity"].append({"type": stype,
                                               "score": base, "vector": vector})
            measurements = {(s["score"], s["vector"], s["type"]) for s in entry["severity"]}
            if len(measurements) == 1:
                score, vector, stype = next(iter(measurements))
                entry.pop("severity")
                entry.update(cvss_score=float(score) if score is not None else None, cvss_vector=vector,
                             cvss_version="3.1" if stype == "CVSS_V31" else "3.0" if stype == "CVSS_V3" else "2.0")
        per_cve[cve] = entry
    return {"summary": "\n\n".join(summary), "sections": sections, "per_cve": per_cve,
            "published": first_text(root, "InitialReleaseDate"), "modified": first_text(root, "CurrentReleaseDate")}


class CiscoPublicAdapter(SnapshotAdapter):
    source = "cisco"
    def load(self, request):
        base = "https://sec.cloudapps.cisco.com/security/center/"
        rows = []
        offset = 0
        seen = set()
        total_initial = None
        while True:
            params = {"publicationTypeIDs": "1,3", "offset": offset, "limit": 100,
                      "sort": "-last_published", "criteria": "exact"}
            page = self.http.json(base + "publicationService.x", params)
            if not isinstance(page, list):
                raise ValueError("Expected Cisco publication JSON array")
            if not page:
                if total_initial is None or offset < total_initial:
                    raise ValueError("Unexpected empty Cisco page")
                break
            total = page[0]["totalCount"]
            if total_initial is None:
                total_initial = total
            if total != total_initial:
                raise ValueError("Cisco listing changed during snapshot; rerun in a fresh cache")
            for row in page:
                identifier = row["identifier"]
                if identifier in seen:
                    raise ValueError("Repeated Cisco advisory during pagination")
                seen.add(identifier)
                rows.append(row)
            offset += len(page)
            if offset >= total:
                break
            if offset % 1000 == 0:
                print(f"  Cisco listing {offset}/{total}", flush=True)
        if len(rows) != total_initial:
            raise ValueError("Cisco totalCount mismatch")
        candidates = [r for r in rows if self.in_window(r.get("firstPublished"), request)]

        def enrich(row):
            identifier = row["identifier"]
            url = row["url"]
            typename = url.split("/content/")[-1].split("/")[0]
            xml_url = f"{base}contentxml/{typename}/{identifier}/cvrf/{identifier}_cvrf.xml"
            p = base_payload(identifier, row["title"], text(row.get("summary")), row["firstPublished"], row["lastPublished"], url)
            p["cwe"] = sorted(set(re.findall(r"CWE-\d+", str(row.get("cwe") or ""))))
            identifiers = cves(row.get("cve"))
            metadata = {"source": self.source, "parser_version": PARSER_VERSION, "severity_label": row.get("severity")}
            detail = None
            # Cisco informational notices do not represent vulnerabilities.
            if identifiers:
                try:
                    body, info = self.http.get(xml_url)
                    detail = parse_cisco_cvrf(body)
                    p["description"] = detail["summary"] or p["description"]
                    p["references"].append({"type": "WEB", "url": xml_url})
                    identifiers = sorted(set(identifiers) | set(detail["per_cve"]))
                    metadata["cvrf_sha256"] = info["sha256"]
                except Exception as exc:
                    metadata["enrichment_error"] = str(exc)
            return row, p, identifiers, metadata, detail

        records = []
        for row, p, identifiers, metadata, detail in self.http.map(enrich, candidates):
            if metadata.get("enrichment_error"):
                self.warnings.append({"advisory_id": row["identifier"], "error": metadata["enrichment_error"]})
            records += split_records(row["identifier"], p, identifiers, metadata, detail["per_cve"] if detail else None)
            self.advisories.append({"advisory_id": row["identifier"], "listing": row, "cvrf": detail})
        self.coverage = {"enumerated_advisories": len(rows), "listing_total": total_initial,
                         "window_advisories": len(candidates), "enumeration_complete": True,
                         "enrichment_failures": len(self.warnings), "publication_type_ids": "1,3"}
        return records


def parse_fortinet_listing(body):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(body, "html.parser")
    section = soup.select_one("section.table-body")
    if section is None:
        raise ValueError("Fortinet listing missing: possibly WAF challenge")
    identifiers = re.findall(r"location.href\s*=\s*'/psirt/(FG-IR-\d+-\d+)'", str(soup))
    identifiers = list(dict.fromkeys(identifiers))
    if not identifiers:
        identifiers = list(dict.fromkeys(re.findall(r"FG-IR-\d+-\d+", section.get_text())))
    total = re.search(r"Total:\s*(\d+)", soup.get_text(" ", strip=True))
    if not total:
        raise ValueError("Missing Fortinet total count")
    return identifiers, int(total.group(1))


def parse_fortinet_detail(body, identifier):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(body, "html.parser")
    main = soup.select_one("section.content")
    if main is None:
        raise ValueError("Fortinet detail missing: possibly WAF challenge")
    meta = {}
    for row in main.select("table.meta tr"):
        cells = row.find_all("td")
        if len(cells) == 2:
            meta[cells[0].get_text(" ", strip=True)] = cells[1].get_text(" ", strip=True)
    if meta.get("IR Number") != identifier:
        raise ValueError("Fortinet advisory ID mismatch")
    sections = {}
    for section in main.select(".detail-item"):
        heading = section.find(["h2", "h3"])
        if heading:
            name = heading.get_text(" ", strip=True)
            heading.extract()
            sections[name] = section.get_text("\n", strip=True)
    title = soup.select_one("h1")
    if title is None:
        title = soup.find("title")
    published = meta.get("Published Date")
    timeline_dates = re.findall(r"\b\d{4}-\d{2}-\d{2}\b", sections.get("Timeline", ""))
    # With no update history, first publication is the only evidenced revision.
    modified = max(timeline_dates) if timeline_dates else published
    p = base_payload(identifier, title.get_text(" ", strip=True), sections.get("Summary", ""),
                     published, modified, "https://www.fortiguard.com/psirt/" + identifier)
    p["cwe"] = sorted(set(re.findall(r"CWE-\d+", sections.get("Summary", ""))))
    affected = []
    product_rows = []
    for row in main.select(".table-responsive table tbody tr"):
        cells = [c.get_text(" ", strip=True) for c in row.find_all("td")]
        if len(cells) != 3:
            continue
        name_branch, versions, solution = cells
        product_rows.append({"product_branch": name_branch, "affected": versions, "solution": solution})
        if versions.lower() in ("not affected", "n/a", "none"):
            continue
        pkg = {"name": name_branch, "ecosystem": "Fortinet"}
        match = re.fullmatch(r"(\d+(?:\.\d+)+)\s+through\s+(\d+(?:\.\d+)+)", versions)
        if match:
            pkg["ranges"] = [{"type": "ECOSYSTEM", "events": [{"introduced": match[1]}, {"last_affected": match[2]}]}]
        elif re.fullmatch(r"\d+(?:\.\d+)+", versions):
            pkg["versions"] = [versions]
        affected.append(pkg)
    p["affected"] = affected
    score = meta.get("CVSSv3 Score") or meta.get("CVSSv4 Score")
    cvss_links = main.select("a[href*='cvss/']")
    if score:
        p["cvss_score"] = float(score)
        version = "4.0" if "CVSSv4 Score" in meta else "3.1"
        query = parse_qs(urlparse(cvss_links[0]["href"].strip()).query) if cvss_links else {}
        version = query.get("version", [version])[0]
        vector = query.get("vector", [None])[0]
        if vector and not vector.startswith("CVSS:"):
            vector = "CVSS:" + version + "/" + vector
        p.update(cvss_version=version, cvss_vector=vector)
    csaf = next((a["href"] for a in main.select("a[href]") if "/psirt/csaf/" in a["href"]), None)
    metadata = {"source": "fortinet", "parser_version": PARSER_VERSION, "source_fields": meta,
                "sections": sections, "product_rows": product_rows,
                "modified_time_basis": "timeline" if timeline_dates else "initial_publication",
                "csaf_url": parse_qs(urlparse(csaf).query).get("csaf_url", [None])[0] if csaf else None}
    return p, cves(meta.get("CVE ID")), metadata


def parse_fortinet_csaf(data, identifier, url):
    """Read the publisher's public CSAF file; verify ID before accepting it."""
    document = data["document"]
    tracking = document["tracking"]
    if tracking["id"] != identifier or document.get("csaf_version") != "2.0":
        raise ValueError("Fortinet CSAF identity/version mismatch")
    per_cve = {}
    descriptions = []
    for vuln in data.get("vulnerabilities", []):
        cve = vuln.get("cve")
        if not cve:
            continue
        refs = vuln.get("references", [])
        desc = "\n\n".join(r.get("summary", "") for r in refs if r.get("summary"))
        if not desc:
            desc = "\n\n".join(n.get("text", "") for n in vuln.get("notes", []) if n.get("category") == "summary")
        descriptions.append(desc)
        entry = {"description": desc, "cwe": [vuln["cwe"]["id"]] if vuln.get("cwe", {}).get("id") else []}
        entry["affected"] = [{"name": p, "ecosystem": "Fortinet"} for p in vuln.get("product_status", {}).get("known_affected", [])]
        scores = [s.get("cvss_v3") or s.get("cvss_v4") or s.get("cvss_v2") for s in vuln.get("scores", [])]
        scores = [s for s in scores if s]
        if len(scores) == 1:
            entry.update(cvss_score=scores[0].get("baseScore"), cvss_vector=scores[0].get("vectorString"), cvss_version=scores[0].get("version"))
        elif scores:
            entry["severity"] = [{"type": "CVSS_V4" if str(s.get("version", "")).startswith("4") else
                                           "CVSS_V2" if str(s.get("version", "")).startswith("2") else
                                           "CVSS_V3" if str(s.get("version", "")) == "3.0" else "CVSS_V31",
                                   "score": s.get("baseScore"), "vector": s.get("vectorString")} for s in scores]
        per_cve[cve] = entry
    payload = base_payload(identifier, document["title"], "\n\n".join(descriptions),
                           tracking["initial_release_date"], tracking["current_release_date"],
                           "https://www.fortiguard.com/psirt/" + identifier)
    payload["references"].append({"type": "WEB", "url": url})
    return payload, sorted(per_cve), {"source": "fortinet", "parser_version": PARSER_VERSION,
                                     "acquisition_format": "official_csaf_cdn", "csaf": data,
                                     "per_cve": per_cve, "affected_scope": "vulnerability_level"}


class FortinetPublicAdapter(SnapshotAdapter):
    source = "fortinet"
    def load(self, request):
        base = "https://www.fortiguard.com/psirt"
        ids = []
        titles = {}
        seen = set()
        total = None
        page = 1
        while True:
            # An absent product parameter silently selects only selected products!
            body, _ = self.http.get(base, {"product": "", "page": page})
            identifiers, count = parse_fortinet_listing(body)
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(body, "html.parser")
            for b in soup.select("section.table-body .row[id] b"):
                match = re.match(r"(FG-IR-\d+-\d+)\s+(.+)", b.get_text(" ", strip=True))
                if match:
                    titles[match[1]] = match[2]
            if total is None:
                total = count
            if total != count:
                raise ValueError("Fortinet count changed; rerun in fresh cache")
            if not identifiers:
                raise ValueError("Unexpected empty Fortinet page")
            if seen.intersection(identifiers):
                raise ValueError("Repeated Fortinet page/advisory")
            ids.extend(identifiers)
            seen.update(identifiers)
            if len(ids) >= total:
                break
            page += 1
            if page > math.ceil(total / 15) + 1:
                raise ValueError("Fortinet pagination safety bound")
            if page % 10 == 0:
                print(f"  Fortinet listing {len(ids)}/{total}", flush=True)
        if len(ids) != total:
            raise ValueError("Fortinet total count mismatch")

        def fetch(identifier):
            # Prefer the publisher's machine-readable public CDN file. This
            # avoids unnecessary loads of large HTML pages and needs no WAF
            # session. Filename derivation is untrusted until ID validation.
            title = titles.get(identifier)
            if title:
                slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
                csaf_url = f"https://filestore.fortinet.com/fortiguard/psirt/csaf_{slug}_{identifier.lower()}.json"
                try:
                    p, identifiers, metadata = parse_fortinet_csaf(self.http.json(csaf_url), identifier, csaf_url)
                    return identifier, p, identifiers, metadata
                except Exception:
                    pass
            try:
                body, info = self.http.get(base + "/" + identifier)
                p, identifiers, metadata = parse_fortinet_detail(body, identifier)
            except Exception:
                # The canonical public hostname is linked in the site's own
                # og:url metadata. Try it once; never solve a WAF challenge.
                try:
                    body, info = self.http.get("https://fortiguard.fortinet.com/psirt/" + identifier)
                    p, identifiers, metadata = parse_fortinet_detail(body, identifier)
                except Exception as exc:
                    return identifier, None, [], {"error": str(exc)}
            metadata["html_sha256"] = info["sha256"]
            return identifier, p, identifiers, metadata

        records = []
        for identifier, p, identifiers, metadata in self.http.map(fetch, ids):
            if p is None:
                self.warnings.append({"advisory_id": identifier, "error": metadata["error"],
                                      "window_membership": "unknown without first-publication detail"})
                continue
            if not self.in_window(p["published_at"], request):
                continue
            # Product table applies at advisory level; keep this scope explicit.
            metadata.setdefault("affected_scope", "advisory_level")
            records += split_records(identifier, p, identifiers, metadata, metadata.get("per_cve"))
            self.advisories.append({"advisory_id": identifier, "payload": p, "cves": identifiers, "metadata": metadata})
        self.coverage = {"enumerated_advisories": len(ids), "listing_total": total, "listing_pages": page,
                         "window_advisories": len(self.advisories), "enumeration_complete": True,
                         "unresolved_details": len(self.warnings),
                         "product_filter": "explicit empty/all", "affected_scope": "advisory_level"}
        return records
