# 第 7、8、9 个情报源：公开采集实现

对应用户提供的位置表：CERT/CC、Cisco PSIRT、Fortinet PSIRT。本实现独立运行，不依赖未推送的 `tools/collect_live_2y.py` 修改，不覆盖原有 fixture 适配器。

## 运行

Python 3.11+；依赖 `pydantic`、`requests`、`beautifulsoup4`。本次验证使用 Python 3.12.7。已安装项目基本依赖时，补装可选依赖：

```powershell
python -m pip install -e ".[live-789]"
```

联网安装也必须按用户的代理规则先验证实际 HTTPS 请求；不能只检查端口。

默认不联网，使用随交付包提供的冻结缓存重放：

```powershell
python tools/collect_sources_789.py --output ../replay-delivery --cache ../live-cache
```

更新在线数据必须显式指定 `--live`，并使用新的缓存目录，以免把不同采集时刻的列表页混为同一个快照：

```powershell
python tools/collect_sources_789.py --live --start 2024-09-10 --end 2026-09-15 --output ../new-delivery --cache ../new-live-cache
```

可加 `--sources certcc cisco` 仅运行指定来源；`--workers 1` 降低请求并发。日期为 UTC，窗口包含开始日、不包含结束日，按来源首次发布公告日期筛选。不是按 CVE 年份，也不是按最后修改时间筛选。

## 接入学长的收集任务

新增文件 `apps/vulntell/sources/public_789.py` 提供三个符合 `SourceRequest/SourcePage` 的适配器：

```python
from apps.vulntell.sources.public_789 import (
    PublicHTTP, CERTCCPublicAdapter, CiscoPublicAdapter, FortinetPublicAdapter,
)

http = PublicHTTP("./live-cache-789")  # 显式联网；先验证 Clash，失败再验证 PulseVPN。
adapter = CERTCCPublicAdapter(http)   # 或 CiscoPublicAdapter / FortinetPublicAdapter
# 使用原来的 collect_adapter(adapter, request, output_dir) 写出批次。
```

建议先分别运行本次独立命令，核验交付结果，再把这三个类替换到学长未推送版本的任务列表中。不要把公开接口响应重新塞入原来的虚构 JSON 格式。

## 入口和检查规则

| 来源 | 实际入口 | 完整性检查 |
| --- | --- | --- |
| CERT/CC | 官方年度 summary → 单条 note → 厂商及漏洞状态 API | 每年度 count 与 IDs 数量一致；按 datefirstpublished 过滤 |
| Cisco | 官方网页使用的 publicationService.x 分页 JSON → 公开 CVRF XML | totalCount 不变；offset 遍历全部；ID 不重复；按 firstPublished 过滤 |
| Fortinet | 显式 product= 空筛选的全部产品列表 → 官方公开 CSAF CDN 文件；无法获得时读公告 HTML | 列表 total 与 ID 数量一致；拒绝挑战页面；CSAF tracking.id 必须与请求 ID 一致 |

Cisco 的 OpenVuln 是另一条需要令牌的正式 API，本实现不使用、不申请或提取令牌。其公开网页接口并非长期稳定的开发者 API，后续需要保持格式回归检查。

Fortinet 的部分 CSAF 文件地址按其他官方公告提供的下载地址格式及列表标题推导。推导本身不作为数据证据；必须实际收到文件并验证 CSAF 版本及公告 ID，才接收记录。不能命中则使用普通公开页面；两条公开路线均失败时列入 warnings，批次标记不完整。没有执行反爬脚本、验证码求解或导出浏览器 Cookie。

## 输出和边界

- `records.cosv.jsonl`、`manifest.json`、`quality.json`：现有仓库批次协议的导入数据、哈希与质量记录。
- `source-observations.jsonl`：映射前的来源观测记录和元数据。
- `advisories.raw.jsonl`：窗口内公告级原始/结构化详情。
- `overview.csv`：便于 Excel 查看的人类可读索引，UTF-8 BOM 编码。
- `coverage.json`：数量、缺失字段、警告与覆盖口径。
- 汇总 `collection-summary.json` 和 `http-audit.json`：三来源结果和请求 URL、HTTP 状态、内容哈希、实际抓取时间；不保存 Cookie、请求授权头或访问令牌。

一条公告可能涉及多个不同漏洞，按“公告 ID / CVE”拆成不同观测，不把这些 CVE 写成彼此等价的 aliases。没有 CVE 的公告也保留；数量统计同时报告公告数、观测数、独立 CVE 数。

CERT 厂商受影响状态保留在 metadata，不伪装成受影响软件包。Cisco CVRF 产品全名、Fortinet CSAF 的产品标识保留来源文字，部分版本范围仍在原始结构或产品文字中；没有可靠结构时不猜版本范围。HTML 提取的范围仅支持有明确边界的 `x through y` 或单一版本。

时间值没有时区或只有日期时按 UTC 日期规范化，这是技术约定，并不证明公告在 UTC 零时发布；用于分钟级“及时性”比较前应重新确认来源时区与精度。窗口内数据是实际抓取时的最新内容，不是截至窗口结束日的历史快照。

公开访问不等于可任意再分发，manifest 中保留研究用途及需遵守来源条款的提示；公开比赛展示或公开发布原始数据前，应核对发布者许可和比赛规则。
