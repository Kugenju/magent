"""Offline regression tests: real formats, truthful windows and no silent truncation."""
from datetime import datetime, timezone
import asyncio
import hashlib
import json
import threading
import pytest

from apps.vulntell.sources.protocol import SourceRecord, SourceRequest
from apps.vulntell.sources.public_789 import (
    PublicHTTP, SnapshotAdapter, CERTCCPublicAdapter, parse_cisco_cvrf,
    parse_fortinet_listing, parse_fortinet_detail, parse_fortinet_csaf, split_records, timestamp,
)


def request(source="test", size=1):
    return SourceRequest(source, "test", "v1", datetime(2024, 9, 10, tzinfo=timezone.utc),
                         datetime(2026, 9, 15, tzinfo=timezone.utc), page_size=size)


class FakeSnapshot(SnapshotAdapter):
    source = "test"
    def load(self, req):
        return [SourceRecord("z", {}), SourceRecord("a", {}), SourceRecord("b", {})]


def test_stable_paging_and_no_implicit_100_limit():
    asyncio.run(check_stable_paging())


async def check_stable_paging():
    adapter = FakeSnapshot(None)
    cursor = None
    ids = []
    while True:
        page = await adapter.fetch_page(request(), cursor)
        ids.extend(r.source_record_id for r in page.records)
        if not page.has_more:
            break
        assert page.next_cursor != cursor
        cursor = page.next_cursor
    assert ids == ["a", "b", "z"]
    with pytest.raises(ValueError):
        await adapter.fetch_page(request(), "-1")
    with pytest.raises(ValueError):
        await adapter.fetch_page(request(size=2))
    class LargeSnapshot(FakeSnapshot):
        def load(self, req):
            return [SourceRecord(str(i).zfill(4), {}) for i in range(205)]
    large = LargeSnapshot(None)
    cur = None
    count = 0
    while True:
        page = await large.fetch_page(request(size=20), cur)
        count += len(page.records)
        if not page.has_more:
            break
        cur = page.next_cursor
    assert count == 205


def test_half_open_first_publication_window():
    adapter = FakeSnapshot(None)
    req = request()
    assert adapter.in_window("2024-09-10T00:00:00Z", req)
    assert adapter.in_window("2026-09-14T23:59:59Z", req)
    assert not adapter.in_window("2026-09-15T00:00:00Z", req)
    assert not adapter.in_window("2024-09-09", req)
    with pytest.raises(ValueError):
        adapter.in_window(None, req)


def test_multi_cve_not_equivalent_aliases():
    records = split_records("ADV-1", {"aliases": []}, ["CVE-2025-1234", "CVE-2025-5678"], {})
    assert [r.source_record_id for r in records] == ["ADV-1/CVE-2025-1234", "ADV-1/CVE-2025-5678"]
    assert records[0].payload["cve_id"] == "CVE-2025-1234"
    assert "CVE-2025-5678" not in records[0].payload["aliases"]
    assert split_records("NO-CVE", {}, [], {})[0].source_record_id == "NO-CVE"


def test_cisco_cvrf_v3_names_and_vulnerability_scope():
    body = b'''<c:cvrfdoc xmlns:c="urn:cvrf" xmlns:v="urn:vuln">
    <c:InitialReleaseDate>2025-01-01T10:00:00</c:InitialReleaseDate>
    <c:Note Title="Summary">Full untruncated summary</c:Note>
    <c:FullProductName ProductID="p1">Cisco Product 1.2</c:FullProductName>
    <v:Vulnerability><v:CVE>CVE-2025-1234</v:CVE>
    <v:Status Type="Known Affected"><v:ProductID>p1</v:ProductID></v:Status>
    <v:ScoreSetV3><v:BaseScoreV3>9.8</v:BaseScoreV3>
    <v:VectorV3>CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H</v:VectorV3></v:ScoreSetV3>
    </v:Vulnerability></c:cvrfdoc>'''
    result = parse_cisco_cvrf(body)
    v = result["per_cve"]["CVE-2025-1234"]
    assert result["summary"] == "Full untruncated summary"
    assert v["affected"][0]["name"] == "Cisco Product 1.2"
    assert v["cvss_score"] == 9.8
    assert v["cvss_version"] == "3.1"
    assert "cwe" not in v  # Do not erase listing CWE if CVRF omits it.
    with pytest.raises(ValueError):
        parse_cisco_cvrf(b"<html>challenge</html>")


def fortinet_html():
    return b'''<html><h1>Test vulnerability</h1><section class="content">
    <div class="detail-item"><h2>Summary</h2><p>Description CWE-79</p></div>
    <div class="detail-item"><h2>Timeline</h2>2025-01-01: Initial publication
    2025-01-10: Update</div><div class="table-responsive"><table><tbody>
    <tr><td>FortiOS 7.2</td><td>7.2.0 through 7.2.8</td><td>Upgrade to 7.2.9</td></tr>
    <tr><td>FortiOS 7.4</td><td>Not affected</td><td>N/A</td></tr></tbody></table></div>
    <table class="meta"><tr><td>IR Number</td><td>FG-IR-25-001</td></tr>
    <tr><td>Published Date</td><td>Jan 1, 2025</td></tr>
    <tr><td>CVSSv3 Score</td><td><a href="https://nvd.nist.gov/vuln-metrics/cvss/v3-calculator?vector=AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H&amp;version=3.1">9.8</a></td></tr>
    <tr><td>CVE ID</td><td>CVE-2025-1234</td></tr></table></section></html>'''


def test_fortinet_actual_html_fields_and_version_ranges():
    payload, ids, metadata = parse_fortinet_detail(fortinet_html(), "FG-IR-25-001")
    assert payload["title"] == "Test vulnerability"
    assert payload["published_at"] == "2025-01-01T00:00:00Z"
    assert payload["modified_at"] == "2025-01-10T00:00:00Z"
    assert ids == ["CVE-2025-1234"]
    assert payload["cvss_score"] == 9.8
    assert payload["cvss_vector"].startswith("CVSS:3.1/")
    assert len(payload["affected"]) == 1
    assert payload["affected"][0]["ranges"][0]["events"][-1] == {"last_affected": "7.2.8"}
    assert metadata["product_rows"][1]["affected"] == "Not affected"


def test_listing_and_challenge_rejection():
    body = b'''<p>Total: <b>2</b></p><section class="table-body">FG-IR-25-001 FG-IR-25-002</section>'''
    assert parse_fortinet_listing(body) == (["FG-IR-25-001", "FG-IR-25-002"], 2)
    with pytest.raises(ValueError):
        parse_fortinet_detail(b"<html><script>challenge</script></html>", "FG-IR-25-001")
    with pytest.raises(ValueError):
        parse_fortinet_listing(b"<html>challenge</html>")


def test_offline_cache_integrity_and_public_host_restriction(tmp_path):
    http = PublicHTTP(tmp_path, offline=True)
    url = "https://kb.cert.org/vuls/api/2024/summary/"
    key = hashlib.sha256(url.encode()).hexdigest()
    body = b'{"count":0,"notes":[]}'
    (tmp_path / (key + ".body")).write_bytes(body)
    (tmp_path / (key + ".json")).write_text(json.dumps({"sha256": hashlib.sha256(body).hexdigest()}))
    assert http.json(url)["count"] == 0
    (tmp_path / (key + ".body")).write_bytes(b"tampered")
    with pytest.raises(ValueError):
        http.get(url)
    with pytest.raises(ValueError):
        http.get("https://example.com/private")
    with pytest.raises(RuntimeError):
        http.get("https://kb.cert.org/missing")


class CERTFake:
    def json(self, url):
        if "/summary/" in url:
            return {"count": 1, "notes": ["VU#123456"]}
        if "/vendors/vuls/" in url:
            return [{"vendor": "Vendor", "status": "Affected"}, {"vendor": "Other", "status": "Not Affected"}]
        if "/vendors/" in url:
            return [{"vendor": "Vendor"}]
        return {"idnumber": "123456", "vuid": "VU#123456", "name": "Real fields",
                "overview": "Summary", "datefirstpublished": "2025-01-01T00:00:00Z",
                "dateupdated": "2025-01-02T00:00:00Z", "cveids": ["CVE-2025-1234"]}
    def map(self, fn, items):
        return list(map(fn, items))


def test_cert_real_api_schema_not_invented_notes_pagination():
    adapter = CERTCCPublicAdapter(CERTFake())
    rows = adapter.load(request("certcc"))
    assert len(rows) == 1
    assert rows[0].payload["cve_id"] == "CVE-2025-1234"
    assert rows[0].payload["published_at"] == "2025-01-01T00:00:00Z"
    assert rows[0].metadata["vendor_vulnerability_statuses"][1]["status"] == "Not Affected"
    assert rows[0].payload["affected"] == []  # Vendors are not packages.


def test_csaf_identity_and_per_cve_scope():
    data = {"document": {"title": "Test", "csaf_version": "2.0", "tracking": {
        "id": "FG-IR-25-001", "initial_release_date": "2025-01-01T00:00:00", "current_release_date": "2025-01-02T00:00:00"}},
        "vulnerabilities": [{"cve": "CVE-2025-1234", "cwe": {"id": "CWE-79"},
            "notes": [{"category": "summary", "text": "Evidence"}],
            "product_status": {"known_affected": ["FortiOS 7.2.0"]},
            "scores": [{"cvss_v3": {"version": "3.1", "baseScore": 7.5, "vectorString": "CVSS:3.1/AV:N"}}]}]}
    p, ids, m = parse_fortinet_csaf(data, "FG-IR-25-001", "https://filestore.fortinet.com/example.json")
    rows = split_records("FG-IR-25-001", p, ids, m, m["per_cve"])
    assert rows[0].payload["cvss_score"] == 7.5
    assert rows[0].payload["cwe"] == ["CWE-79"]
    assert rows[0].payload["description"] == "Evidence"
    assert m["affected_scope"] == "vulnerability_level"
    with pytest.raises(ValueError):
        parse_fortinet_csaf(data, "FG-IR-25-999", "https://filestore.fortinet.com/example.json")


def test_cvss4_not_mislabeled_as_cvss2():
    from apps.vulntell.cosv.mapper import _extract_severity
    result = _extract_severity({"cvss": {"version": "4.0", "score": 8.7, "vector": "CVSS:4.0/AV:N"}})
    assert result[0].type.value == "CVSS_V4"
